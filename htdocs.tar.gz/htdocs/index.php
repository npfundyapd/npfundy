<!DOCTYPE html>
<?php session_start(); ?>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>NPFundy</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/index.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    </head>
    <body>
        <?php include("php/header.php"); ?>
        <section id="main"></section>
        <?php include("php/footer.php"); ?>
    </body>
    <script type="text/javascript" src="js/pageBuilder.js"></script>
</html>
<script type="text/javascript">
	var email = "<?php echo $_SESSION['email']; ?>";
	console.log('email: '+email);
	if (email != null && email != undefined && email != "") {
		$('#login').prop('hidden', true);
		$('#logout').prop('hidden', false);
		$('#profileBtn').prop('hidden', false);
	} else {
		$('#login').prop('hidden', false);
		$('#logout').prop('hidden', true);
		$('#profileBtn').prop('hidden', true);
	}
</script>
