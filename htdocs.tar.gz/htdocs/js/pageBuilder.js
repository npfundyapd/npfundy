$(document).ready(function() {
	$.ajax({url: "php/home.php",
		type: "GET",
		success: function(data, status) {
			$('#main').html(data);
		}
	});
});

$('#letsGo').click(function() {
	$.ajax({url: "php/signupform.php",
		type: "GET",
		success: function(data, status) {
			$('#main').html(data);	
		}
	});
});

$('#login').click(function() {
	$.ajax({url: "php/loginform.php",
		type: "GET",
		success: function(data, status) {
			$('#main').html(data);
		}
	});
});

$('#logout').click(function() {
	$.ajax({url: "php/logout.php",
		type: "GET",
		success: function(data, status) {

			if (data == 1) {
				$('#logout').prop('hidden', 'true');
				$('#orgSearchField').prop('hidden', 'true');
				$('#orgSearchBtn').prop('hidden', 'true');
				$('#login').prop('hidden', 'false');
				$('#profileBtn').prop('hidden', 'true');
			location.reload();
			}
		}
	
	});
});

$('#profileBtn').click(function() {
	$.ajax({url: "php/profile.php",
		type: "GET",
		success: function(data, status) {
			$('#main').html(data);
		}
	});
});

$('#processBtn').click(function() {
	$.ajax({url: "php/ourprocess.php",
		type: "GET",
		success: function(data, status) {
			$('#main').html(data);
		}
	});
});

$('#orgSearchBtn').click(function() {
	var criteria = $('#orgSearchField').val();
	$.ajax({url: "php/orgSearchResult.php",
		type: "GET",
		success: function(data, status) {
			$('#main').html(data);

			$.ajax({url: "php/fetchOrgs.php",
				type: "GET",
				data: {criteria: criteria},
				success: function(data, status) {
					var orgList = "";
					for (var i = 0; i < data.length; i++) {
						orgList += "<button id='"+data[i]['EIN']+"' class='btn btn-link' onclick='visitOrgPage(this.id);'>"+data[i]['NAME']+"</button><br>";
					}
					$('#orgList').html(orgList);
				}
				
			});
		}
		
	});
});

function visitOrgPage(id)
{
	$.ajax({
		url: "php/organization.php",
		type: "GET",
		data: {EIN: id},
		success: function(data, status) {
			$('#main').html(data);
			console.log('id: '+id);
			$('#headerEIN').html(id);
		}
	});
}
