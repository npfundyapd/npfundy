<?php
	session_start();

	$email = $_POST['email'];
	$password = $_POST['password'];
	include("conn.php");
	$conn = mysqli_connect($host, $user, $pwd, $name, 3306);

	if ($conn->connect_error) {
		die("Connection failed " . $conn->connect_error);
	} 
	//echo "Connected successfully\n";
	
	/*if (!isset($email, $password) || empty($email, $password)) {
		exit("You must include your email and password to log in.");
	}*/

	$stmt = $conn->prepare("SELECT * FROM USERS WHERE EMAIL = ?");
	$stmt->bind_param("s", $email);
	$stmt->execute();
	$stmt->store_result();

	if ($stmt->num_rows > 0) {
		$stmt->bind_result($userID, $email, $phone, $actualpwd, $firstname, $lastname, $altEmail, $mobilePhone, $streetAddress);
		$stmt->fetch();

		if (password_verify($password, $actualpwd)) {
			session_regenerate_id();
			$_SESSION['loggedin'] = TRUE;
			$_SESSION['userID'] = $userID;
			$_SESSION['email'] = $email;
			$_SESSION['altEmail'] = $altEmail;
			$_SESSION['phone'] = $phone;
			$_SESSION['mobilePhone'] = $mobilePhone;
			$_SESSION['firstname'] = $firstname;
			$_SESSION['lastname'] = $lastname;
			$_SESSION['streetAddress'] = $streetAddress;
			echo "Login success";
		} else {
			echo "Incorrect email/password.";
		}
	} else {
		echo "Incorrect email/password.";
	}

	$stmt->close();
	$conn->close();

?>
