<?php
	session_start();
	$email = $_GET['email'];

	include('conn.php');
	
	$conn = mysqli_connect($host, $user, $pwd, $name, 3306);

	if ($conn->connect_error) {
		die("Connection failed " . $conn->connect_error);
	} 

	$stmt = $conn->prepare("SELECT 1 FROM USERS WHERE EMAIL = ?");
	$stmt->bind_param("s", $email);
	$stmt->execute();
	$stmt->store_result();

	if ($stmt->num_rows > 0) {
		echo 1;
	} else {
		echo 0;
	}

	$stmt->close();
	$conn->close();	
?>
