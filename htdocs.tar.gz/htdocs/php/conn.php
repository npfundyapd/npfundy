<?php

	$host = 'ls-c5f88b1f019807be964db312cc9025b60cbde3e2.cvl7kueomgpl.ca-central-1.rds.amazonaws.com';
	$port = 3306;
	$user = 'dbmasteruser';
	$pwd = 'F_`UO0DPT{;[0uyzTPl,wvMIV|X)7<Q!';
	$name =	'dbmaster';

?>
