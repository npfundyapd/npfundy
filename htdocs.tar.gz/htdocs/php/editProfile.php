<?php session_start(); ?>
<div id="profileContainer">
	<form id="editProfileForm">
		<div class="form-group">
			<label for="firstname">First name:</label>
			<input type="text" class="form-control" id="firstname">
		</div>
		<div class="form-group">
                        <label for="lastname">Last name:</label>
                        <input type="text" class="form-control" id="lastname">
                </div>
		<div class="form-group">
                        <label for="email">Email:</label>
                        <input type="text" class="form-control" id="email" readonly>
                </div>
		<div class="form-group">
                        <label for="altEmail">Alternate Email:</label>
                        <input type="text" class="form-control" id="altEmail">
                </div>
		<div class="form-group">
                        <label for="homePhone">Home Phone:</label>
                        <input type="text" class="form-control" id="homePhone">
                </div>
		<div class="form-group">
                        <label for="mobilePhone">Mobile Phone:</label>
                        <input type="text" class="form-control" id="mobilePhone">
                </div>
		<div class="form-group">
                        <label for="streetAddress">Street Address:</label>
                        <input type="text" class="form-control" id="streetAddress">
                </div>
		<button type="button" class="btn btn-primary" id="submitProfileChanges">Submit</button>
	</form>
</div>
<script type="text/javascript">

</script>
