<?php
	session_start();
	
	$criteria = "%" . $_GET['criteria'] . "%";
	include("conn.php");

	$conn = mysqli_connect($host, $user, $pwd, $name, 3306);

	if ($conn->connect_error) {
		die("Connection failed " . $conn->connect_error);
	} 

	$stmt = $conn->prepare("SELECT `NAME`, `EIN` FROM ORGANIZATION WHERE NAME LIKE ?");
	$stmt->bind_param("s", $criteria);
	$stmt->execute();
	//$stmt->store_result();
	
	$result = $stmt->get_result();
	/*if ($stmt->num_rows > 0) {
		$stmt->bind_result($name, $EIN);
		//while ($r = $stmt->fetch()) {
		while ($r = $stmt->fetch()) {
			//$result[] = $name;
			//$result[]['NAME'] = $name;
			//$result[]['EIN'] = $EIN;
		}
		
	}*/
	
	header('Content-Type: application/json');
	//echo json_encode($result);

	if ($result->num_rows > 0) {
		while ($r = $result->fetch_assoc()) {
			$res[] = $r;
		}
	}
	echo json_encode($res);
	$stmt->close();
	$conn->close();
?>
