<footer>
	<div>
		<a href="#">Contact Us</a><br>
		<a href="#">Terms of Service</a>`
	</div>
</footer>
