<header>
    <nav class="navbar navbar-expand-md bg-light">
      <a class="navbar-brand" href="#">
            <img src="img/logo_transparent_bg.png" alt="NP fundy test" style="width:80px" href="home.php">  
        </a>
      <button class="navbar-toggler navbar-light" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav ml-auto">
	  <li class="nav-item">
		<div class="btn-group">
			<input type="text" id="orgSearchField" placeholder="Organization name...">
			<button type="button" id="orgSearchBtn" class="btn btn-primary">Search</button> 
	 </li>
          <li class="nav-item">
            <button type="button" id="processBtn" class="btn btn-link" href="#">About Us</button>
          </li>
	  <li class="nav-item">
            <button type="button" id="pricingBtn" class="btn btn-link" href="#">Pricing</button>
          </li>
          <li class="nav-item">
            <button type="button" id="login" class="btn btn-link" href="#">Login</button>
          </li>
	  <li>
	  	<button type="button" id="logout" class="btn btn-link" hidden>Logout</button>
	  </li>
          <li class="nav-item">
			<button type="button" id="profileBtn" class="btn btn-info" href="#" hidden>Profile</button>
          </li>
        </ul>
      </div>  
    </nav>
</header>
