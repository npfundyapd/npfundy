<div id="home">
		<div id="welcome">
			<h2>Simplify your fundraising efforts</h2>
		</div>
		<div class="homeContainer input-group">
			<div class="form-row1">
				<div class="input-group">
					<input type="email" class="form-control" id="email" name="email" placeholder="Email" required>
					<div class="input-group-btn">
						<button id="letsGo" class="btn btn-primary" type="button">Let's Go</button>
					</div>
				</div>
			</div>
		</div>
	<!--<div class="flex_space_between width75 centeredlr">
		<div class="maxwidth20">
			<h4>Virtual raffle tickets</h4>
			<p>Forget about paper tickets.  Keep your raffle simple with online tickets.</p>
		</div>
		<div class="maxwidth20">
			<h4>Monitor your fundraising</h4>
			<p>Easily manage your ticket sales with our online platform. NPFundy will do the math for you.</p>
		</div>
		<div class="maxwidth20">
			<h4>Custom prizes</h4>
			<p>Add one or multiple custom prizes to your raffles.  Winners can be chosen manually or automatically when the raffle ends.</p>
		</div>
	</div>-->
</div>

<script type="text/javascript">

$('#letsGo').click(function() {

	var email = $('#email').val();

	$.ajax({
		url: "php/checkEmail.php",
		type: "GET",
		data: {email: email},
		success: function(data, status) {
			if (data == 1) {
				//go to login page
				
				$.ajax({
					url: "php/loginform.php",
					type: "GET",
					success: function(data, status) {
						$('#main').html(data);
						$('#email').val(email);
					}
				});

			} else {
				//go to sign up page
				$.ajax({
					url: "php/signupform.php",
					type: "GET",
					success: function(data, status) {
						$('#main').html(data);
						$('#email').val(email);
					}
				});
			}
		}
	});
});

</script>
