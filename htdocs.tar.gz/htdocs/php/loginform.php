<div id="loginContainer">
	<h1>Login</h1>
	<form action="" id="loginForm">
		<div class="form-group">
    			<input type="email" class="form-control" placeholder="Enter email address" id="email">
  		</div>
  		<div class="form-group">
    			<input type="password" class="form-control" placeholder="Enter password" id="pwd">
  		</div>
  		<div id="buttoncenter">
		<button type="button" class="btn btn-primary" id="loginBtn">Submit</button>
        <button type="button" id="getStarted" class="btn btn-link" href="#">Create Account</button>
		<button type="button" class="btn btn-info" id="resetPassword">Reset Password</button>
		</div>
	</form>
</div>
<script type="text/javascript">
	$('#loginBtn').click(function() {
		email = $('#email').val(),
		pwd = $('#pwd').val();
		$.ajax({
			url: "php/authenticate.php",
			type: "POST",
			data: {email: email, password: pwd},
			success: function(data, status) {
				alert(data);

				if (data == "Login success") {
					$.ajax({url: "php/profile.php",
						type: "GET",
						success: function(data, status) {
							$('#main').html(data);
							$('#logout').prop('hidden', false);
							$('#orgSearchField').prop('hidden', false);
							$('#orgSearchBtn').prop('hidden', false);
							$('#login').prop('hidden', true);
							$('#profileBtn').prop('hidden', false);
						}
					});
				}
			}
		});
	});
	
$('#getStarted').click(function() {
	$.ajax({url: "php/signupform.php",
		type: "GET",
		success: function(data, status) {
			$('#main').html(data);	
		}
	});
});

</script>
