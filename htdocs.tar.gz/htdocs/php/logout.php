<?php

session_start();

unset($_SESSION['loggedin']);
unset($_SESSION['userID']);
unset($_SESSION['email']);
unset($_SESSION['phone']);
unset($_SESSION['firstname']);
unset($_SESSION['lastname']);

echo 1;
?>
