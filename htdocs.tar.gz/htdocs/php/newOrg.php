<div id="newOrgContainer">
	<form id="newOrgForm" action="">
		<div class="form-group">
			<input type="text" class="form-control" id="orgName" placeholder="Organization Name">
		</div>
		<div class="form-group">
			<input type="text" class="form-control" id="EIN" placeholder="EIN number">
		</div>
		<div class="form-group form-check">
			<label class="form-check-label">
				<input class="form-check-input" type="checkbox" id="confirm501c3"> This is a 501(c)3 organization
			</label>
		</div>
		<button type="button" id="newOrgBtn" class="btn btn-primary">Create Organization</button>
		<button type="button" id="cancelBtn" class="btn btn-danger">Cancel</button>
	</form>
</div>
<script type="text/javascript">
	
	$('#newOrgBtn').click(function() {
		var EIN = $('#EIN').val(),
		    name = $('#orgName').val(),
		    checked = $('#confirm501c3').prop('checked');
		
		if (checked == true) {
			$.ajax({url: "php/submitOrg.php",
				type: "POST",
				data: {EIN: EIN, name: name},
				success: function(data, status) {
					if (data == 1) {
						alert("Organization saved.");
					}
					else {
						alert("Error: Organization could not be created.");
					}
				}
			});
		}
		else {
			alert('Must be a 501(c)3 organization to register.');
		}
	});
	
	$('#cancelBtn').click(function() {
		$.ajax({url: "php/profile.php",
			type: "GET",
			success: function(data, status) {
				$('#main').html(data);
			}
		});
	});
</script>
