<div id="orgSearchResultContainer">
	<div id="orgList"></div>	
</div>
