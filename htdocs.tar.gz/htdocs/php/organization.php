<?php
	session_start();

	$id = $_GET['EIN'];
	
	include('conn.php');
	$conn = mysqli_connect($host, $user, $pwd, $name, 3306);

	if ($conn->connect_error) {
		die("Connection failed " . $conn->connect_error);
	} 

	$stmt = $conn->prepare("SELECT EIN, NAME, CREATED_BY, CREATED_DATE, STATUS FROM ORGANIZATION WHERE EIN = ?");
	$stmt->bind_param('i', $id);
	$stmt->execute();
	$stmt->store_result();

	if ($stmt->num_rows > 0) {
		$stmt->bind_result($EIN, $name, $creator, $createdate, $status);
		$stmt->fetch();
		//echo 'NAME: ' . $name;
	}

	//echo 'name outside if: ' . $name;
	$stmt->close();
	$conn->close();
?>

<div id="orgContainer">
	<div id="orgHeader" class="flex_space_between">
		<h1 id="orgName"> <?php print($name); ?> </h1>
		<div class="flex_space_between" id="EINStatus">
			<p id="headerEIN">EIN</p>
			<p> </p>
			<p id="headerStatus"> <?php print($status); ?> </p>
		</div>
	</div>
	<div class="flexSpaceAround">
		<div class="flex_space_between" id="orgInfoTables">
			<table class="table table-striped" id="contactInfoTable">
				<thead>
					<tr>
						<th>Contact Info</th>
					</tr>
				</thead>
				<tbody id="contactInfoTbody">
				</tbody>
			</table>
			<table class="table table-striped" id="addressLocationInfoTable">
				<thead>
					<tr>
						<th>Address and Location Info</th>
					</tr>
				</thead>
				<tbody id="addressLocationTbody"></tbody>
			</table>
		</div>
		<div id="buttonContainer">
			<h3>Actions</h3>
			<button type="button" class="btn btn-primary" id="newEventBtn">Create New Event</button><br>
			<button type="button" class="btn btn-primary" id="updateOrgBtn">Update Organization</button><br>
			<button type="button" class="btn btn-primary" id="orgReportingBtn">Organization Reporting</button><br>
			<button type="button" class="btn btn-primary" id="verifyOrg">Verify Organization</button><br>
			<button type="button" class="btn btn-primary" id="administratorsBtn">Administrators</button><br>
			<button type="button" class="btn btn-primary" id="createSupportTicket">Create Support Ticket</button>
		</div>		
	</div>
	<div id="eventsContainer">
		<table class="table table-striped" id="currentEventsTable">
			<thead>
				<tr>
					<th>Event Title</th>
					<th>Location</th>
					<th>Start Date</th>
					<th>End Date</th>
					<th>Status</th>
					<th>Activities</th>
					<th>Shareable Link</th>
				</tr>
			</thead>
			<tbody id="currentEventsTbody"></tbody>
		</table>
		<table class="table table-striped" id="eventHistoryTable">
			<thead>
				<tr>
					<th>Event Title</th>
					<th>Location</th>
					<th>Start Date</th>
					<th>End Date</th>
					<th>Activities</th>
				</tr>
			</thead>
			<tbody id="eventHistoryTbody"></tbody>
		</table>
	</div>
</div>
