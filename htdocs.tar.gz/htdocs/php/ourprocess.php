<?php session_start(); ?>
<div id="profileContainer">
	<div class="flexSpaceAround">
		<div id="infoContainer" class="maxwidth50">
			<h2>We are a fundraising site, built specifically for small to medium sized non-profits.</h2>
		</div>
	</div>
</div>