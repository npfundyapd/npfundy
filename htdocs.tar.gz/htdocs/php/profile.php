<?php session_start(); ?>
<div id="profileContainer">
	<div class="flexSpaceAround">
		<div id="avatarContainer">
			<img id="profilePic" src="" alt="Profile Photo">
		</div>
		<div id="infoContainer" class="maxwidth50">
			<table class="table table-striped">
				<tbody>
					<tr><td>Name</td><td><?php echo $_SESSION['firstname'] . ' ' . $_SESSION['lastname']; ?></td></tr>
					<tr><td>Primary Email</td><td><?php echo $_SESSION['email']; ?></td></tr>
					<tr><td>Alternate Email</td><td><?php echo $_SESSION['altEmail']; ?></td></tr>
					<tr><td>Home Phone</td><td><?php echo $_SESSION['phone']; ?></td></tr>
					<tr><td>Mobile Phone</td><td><?php echo $_SESSION['mobilePhone']; ?></td></tr>
					<tr><td>Street Address</td><td><?php echo $_SESSION['streetAddress']; ?></td></tr>
				</tbody>
			</table>
		</div>
		<div class="span2">
			<button id="editProfile" type="button" class="btn btn-primary btn-block">Edit Profile</button><br>
			<button id="createOrg" type="button" class="btn btn-primary btn-block">Create Org</button><br>
			<button id="deactivate" type="button" class="btn btn-danger btn-block">Deactivate Profile</button>
		</div>
	</div>
	<div id="favoriteOrgs" class="flexSpaceAround">
		<h3>Favorite Organizations</h3>
	</div>
	<div id="favoriteEvents" class="flexSpaceAround">
		<h3>Favorite Events</h3>
	</div>
</div>
<script type="text/javascript">

$('#createOrg').click(function() {
	$.ajax({url: "php/newOrg.php",
		type: "GET",
		success: function(data, status) {
			$('#main').html(data);
		}
		
	});
});

$('#editProfile').click(function() {
	$.ajax({url: "php/editProfile.php",
		type: "GET",
		success: function(data, status) {
			$('#main').html(data);
		}
	});
});

$('.myButton').width(
    Math.max.apply(
        Math,
        $('.myButton').map(function(){
            return $(this).outerWidth();
        }).get()
    )
);
</script>
