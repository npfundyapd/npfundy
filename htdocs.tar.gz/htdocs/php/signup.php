<?php
	include("conn.php");
	
	$conn = mysqli_connect($host, $user, $pwd, $name, 3306);
	if (mysqli_connect_errno()) {
		exit('Failed to connect to database.');
	}

	if ($stmt = $conn->prepare('INSERT INTO USERS (EMAIL, ALTEMAIL, FIRSTNAME, LASTNAME, PASSWORD, PHONE, MOBILEPHONE, STREETADDRESS)
				    VALUES (?, ?, ?, ?, ?, ?, ?, ?)')) {
		$email = $_POST['email'];
		$altEmail = $_POST['altEmail'];
		$firstname = $_POST['firstname'];
		$lastname = $_POST['lastname'];
		$passwd = PASSWORD_HASH($_POST['passwd'], PASSWORD_DEFAULT);
		$phone = $_POST['phone'];
		$mobilePhone = $_POST['mobilePhone'];
		$streetAddress = $_POST['streetAddress'];

		$stmt->bind_param('sssssiis', $email, $altEmail, $firstname, $lastname, $passwd, $phone, $mobilePhone, $streetAddress);

		if ($stmt->execute()) {
			echo 1;
		} else {
			echo 'Error: Account could not be created.';
		}

		$stmt->close();
	}
?>
