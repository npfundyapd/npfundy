<div id="signUpContainer">
	<form id="signUpForm" action="">
		<div class="form-group">
			<label for="firstname">First Name:</label>
			<input type="text" class="form-control" placeholder="First Name" id="firstname">
		</div>
		<div class="form-group">
                        <label for="lastname">Last Name:</label>
                        <input type="text" class="form-control" placeholder="Last Name" id="lastname">
                </div>
		<div class="form-group">
    			<label for="email">Email address:</label>
    			<input type="email" class="form-control" placeholder="Email Address" id="email" required>
  		</div>
		<div class="form-group">
			<label for="altEmail">Alternate Email:</label>
			<input type="email" class="form-control" placeholder="Alternate Email" id="altEmail">
		</div>
		<div class="form-group">
			<label for="phone">Home Phone:</label>
			<input type="tel" class="form-control" placeholder="123-456-5678" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}" id="phone" required></input>
		</div>
		<div class="form-group">
                        <label for="mobilePhone">Mobile Phone:</label>
                        <input type="tel" class="form-control" placeholder="123-456-5678" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}" id="mobilePhone" required></input>
                </div>
		<div class="form-group">
			<label for="streetAddress">Street Address:</label>
			<input type="text" class="form-control" placeholder="Street Address" id="streetAddress" required></input>
		</div>
		<div class="form-group">
                        <label for="password">Password:</label>
                        <input type="password" class="form-control" placeholder="Password" id="password" required>
                </div>
		<div class="form-group">
                        <label for="retypePassword">Retype Password:</label>
                        <input type="password" class="form-control" placeholder="Retype Password" id="retypePassword" required>
                </div>
		<div class="form-group">
			<button type="button" class="btn btn-primary" id="signUpSubmit">Submit</button>
		</div>

	</form>
</div>
<script type="text/javascript">

$('#signUpSubmit').click(function() {

	var email = $('#email').val(),
	    altEmail = $('#altEmail').val(),
	    firstname = $('#firstname').val(),
	    lastname = $('#lastname').val(),
	    passwd = $('#password').val(),
	    phone = $('#phone').val(),
	    mobilePhone = $('#mobilePhone').val(),
	    streetAddress = $('#streetAddress').val();

	$.ajax({url: "php/signup.php",
		type: "POST",
		data: {email: email,
		       altEmail: altEmail, 
		       firstname: firstname, 
		       lastname: lastname, 
		       passwd: passwd, 
		       phone: phone,
		       mobilePhone: mobilePhone,
		       streetAddress: streetAddress},
		success: function(data, status) {
			if (data == 1) {
				alert("Profile created.");
			} else {
				alert("Failed to create profile.");
			}
		}
	});
});

</script>
