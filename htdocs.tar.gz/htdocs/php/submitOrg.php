<?php

	session_start();

	include("conn.php");
	
	$conn = mysqli_connect($host, $user, $pwd, $name, 3306);
	if (mysqli_connect_errno()) {
		exit('Failed to connect to database.');
	}

	if ($stmt = $conn->prepare('INSERT INTO ORGANIZATION (EIN, NAME)
				    VALUES (?, ?)')) {
		$EIN = $_POST['EIN'];
		$name = $_POST['name'];

		$stmt->bind_param('is', $EIN, $name);

		if ($stmt->execute()) {
			echo 1;
		} else {
			echo 'Error: Organization could not be saved.';
		}

		$stmt->close();
	}
?>

