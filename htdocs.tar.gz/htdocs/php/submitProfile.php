<?php

session_start();

$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$pwd = PASSWORD_HASH($_POST['pwd'], PASSWORD_DEFAULT);

include("conn.php");

$conn = mysqli_connect($host, $user, $pwd, $name);

if (mysqli_connect_errno()) {
	exit('Failed to connect to database:' .mysqli_connect_error());
}

if (!isset($email) || empty($email) || !isset($phone) || empty($phone) || !isset($pwd) || empty($pwd)) {
	exit('Error: Missing required fields.');
}

if ($stmt = $conn->prepare('INSERT INTO USERS (FIRSTNAME, LASTNAME, EMAIL, PHONE, PASSWORD) VALUES (?, ?, ?, ?, ?)')) {
	$stmt->bind_param('');
}


?>
