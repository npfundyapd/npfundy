
<?php

phpinfo();

?>
